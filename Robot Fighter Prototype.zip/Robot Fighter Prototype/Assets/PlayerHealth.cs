﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Fighter : MonoBehaviour
{
    public Slider healthBarSlider;
    public int currentHealth;
    public int maxHealth;
    public Text healthText;
    bool isLose;
    void Start()
    {
        currentHealth = maxHealth;
        

    }
    void OnCollisionEnter(Collision _collision)
    {
        if(_collision.gameObject.tag == "OpponentFist1" && _collision.gameObject.tag == "OpponentFist2")
        {
            currentHealth -= 5;
            healthText.text = currentHealth.ToString();
            print(currentHealth);
        }
    }

   

    

    void Update()
    {
        healthBarSlider.maxValue = maxHealth;
        healthBarSlider.value = currentHealth;
        healthText.text = currentHealth.ToString() + " / " + maxHealth.ToString();
        if(currentHealth <= 0)
        {
           
            SceneManager.LoadScene(1);
        }
        
       
    }
    

    

    
}
